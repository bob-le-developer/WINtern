import React from 'react'

import { Helmet } from 'react-helmet'

import './business-post.css'

const BusinessPost = (props) => {
  return (
    <div className="business-post-container">
      <Helmet>
        <title>BusinessPost - Wintern</title>
        <meta property="og:title" content="BusinessPost - Wintern" />
      </Helmet>
      <div className="business-post-container01">
        <div className="business-post-container02">
          <div className="business-post-container03">
            <span className="business-post-text">Job Title</span>
          </div>
          <input
            type="text"
            placeholder="Input the Title of Your Job Here"
            className="business-post-textinput input"
          />
        </div>
        <div className="business-post-container04">
          <div className="business-post-container05">
            <span className="business-post-text1">Job Description</span>
          </div>
          <textarea
            placeholder="Enter Details of Your Job Including Hours, Wage, Qualifications, etc."
            className="business-post-textarea textarea"
          ></textarea>
        </div>
        <div className="business-post-container06">
          <div className="business-post-container07">
            <span className="business-post-text2">Upload Images</span>
          </div>
        </div>
        <div className="business-post-container08">
          <div className="business-post-container09">
            <span className="business-post-text3">Select Tags</span>
          </div>
          <div className="business-post-container10">
            <select className="business-post-select">
              <option value="Option 1">Option 1</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 3">Option 3</option>
            </select>
            <select className="business-post-select1">
              <option value="Option 1">Option 1</option>
              <option value="Option 1">Option 1</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 3">Option 3</option>
              <option value="Option 3">Option 3</option>
            </select>
            <select className="business-post-select2">
              <option value="Option 1">Option 1</option>
              <option value="Option 1">Option 1</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 3">Option 3</option>
              <option value="Option 3">Option 3</option>
            </select>
            <select className="business-post-select3">
              <option value="Option 1">Option 1</option>
              <option value="Option 1">Option 1</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 3">Option 3</option>
              <option value="Option 3">Option 3</option>
            </select>
            <select className="business-post-select4">
              <option value="Option 1">Option 1</option>
              <option value="Option 1">Option 1</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 2">Option 2</option>
              <option value="Option 3">Option 3</option>
              <option value="Option 3">Option 3</option>
            </select>
          </div>
        </div>
        <button type="button" className="business-post-button button">
          Submit
        </button>
      </div>
    </div>
  )
}

export default BusinessPost
