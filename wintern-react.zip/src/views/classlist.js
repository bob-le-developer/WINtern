import React from 'react'

import { Helmet } from 'react-helmet'

import './classlist.css'

const Classlist = (props) => {
  return (
    <div className="classlist-container">
      <Helmet>
        <title>Classlist - Wintern</title>
        <meta property="og:title" content="Classlist - Wintern" />
      </Helmet>
    </div>
  )
}

export default Classlist
