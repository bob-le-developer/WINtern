import React from 'react'
import { Link } from 'react-router-dom'

import { Player } from '@lottiefiles/react-lottie-player'
import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Wintern</title>
        <meta property="og:title" content="Wintern" />
      </Helmet>
      <span className="home-text">
        <span className="home-text1">WIN</span>
        <span className="home-text2">tern</span>
      </span>
      <span className="home-text3">
        <span>
          Bridging Futures, Connecting Talent.
          <span
            dangerouslySetInnerHTML={{
              __html: ' ',
            }}
          />
        </span>
        <br></br>
        <span>The Gateway to Your First Career Success.</span>
      </span>
      <Link to="/teacher-interface" className="home-navlink button">
        Teacher
      </Link>
      <Link to="/student-interface" className="home-navlink1 button">
        Student
      </Link>
      <Link to="/business-interface" className="home-navlink2 button">
        Business
      </Link>
      <Player
        src="https://lottie.host/bddd58fd-ee9b-4baa-97ba-a18c27983fb8/qrUYf7k1Yv.json"
        loop="true"
        speed="1"
        autoplay="true"
        background="transparent"
        className="home-lottie-node"
      ></Player>
      <Link to="/sign-up" className="home-navlink3 button">
        Sign Up
      </Link>
    </div>
  )
}

export default Home
