import React from 'react'
import { Link } from 'react-router-dom'

import { Helmet } from 'react-helmet'

import './sign-up.css'

const SignUp = (props) => {
  return (
    <div className="sign-up-container">
      <Helmet>
        <title>Sign-Up - Wintern</title>
        <meta property="og:title" content="Sign-Up - Wintern" />
      </Helmet>
      <div className="sign-up-hero">
        <div className="sign-up-container1">
          <h1 className="sign-up-text">
            <span>
              Opportunities Around
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <span className="sign-up-text02">You</span>
            <span>
              , Suited to
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <span className="sign-up-text04">Your</span>
            <span> Needs</span>
          </h1>
          <span className="sign-up-text06">
            <span>
              <span>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non
                volutpat turpis.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <span>
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </span>
            <span>
              <span>
                Mauris luctus rutrum mi ut rhoncus. Integer in dignissim tortor.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <span>
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </span>
          </span>
          <div className="sign-up-btn-group">
            <Link to="/sign-up2" className="sign-up-navlink button">
              Get Started
            </Link>
            <button className="sign-up-button button">Learn More</button>
          </div>
        </div>
        <img
          alt="image"
          src="https://climate.nasa.gov/rails/active_storage/blobs/redirect/eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaHBBekJPQWc9PSIsImV4cCI6bnVsbCwicHVyIjoiYmxvYl9pZCJ9fQ==--3b36751f495c3666073fa4d33e9eb372ae09de25/ccfid_86349_2015314061422_image-768px.jpg?disposition=inline"
          className="sign-up-image"
        />
      </div>
    </div>
  )
}

export default SignUp
