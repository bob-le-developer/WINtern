import React from 'react'

import { Helmet } from 'react-helmet'

import JobPost from '../components/job-post'
import './jobs-listing.css'

const JobsListing = (props) => {
  return (
    <div className="jobs-listing-container">
      <Helmet>
        <title>Jobs-Listing - Wintern</title>
        <meta property="og:title" content="Jobs-Listing - Wintern" />
      </Helmet>
      <div className="jobs-listing-container1">
        <select className="jobs-listing-select Options">
          <option value="Option 1">Option 1</option>
          <option value="Option 2">Option 2</option>
          <option value="Option 3">Option 3</option>
        </select>
        <select className="jobs-listing-select1 Options">
          <option value="Option 1">Option 1</option>
          <option value="Option 1">Option 1</option>
          <option value="Option 2">Option 2</option>
          <option value="Option 2">Option 2</option>
          <option value="Option 3">Option 3</option>
          <option value="Option 3">Option 3</option>
        </select>
        <select className="jobs-listing-select2 Options">
          <option value="Option 1">Option 1</option>
          <option value="Option 1">Option 1</option>
          <option value="Option 1">Option 1</option>
          <option value="Option 2">Option 2</option>
          <option value="Option 2">Option 2</option>
          <option value="Option 2">Option 2</option>
          <option value="Option 3">Option 3</option>
          <option value="Option 3">Option 3</option>
          <option value="Option 3">Option 3</option>
        </select>
      </div>
      <div className="jobs-listing-blog">
        <JobPost
          imageSrc="https://i.stack.imgur.com/mwFzF.png"
          profileSrc="https://i.stack.imgur.com/mwFzF.png"
          rootClassName="rootClassName3"
        ></JobPost>
        <JobPost
          imageSrc="https://i.stack.imgur.com/mwFzF.png"
          profileSrc="https://i.stack.imgur.com/mwFzF.png"
          rootClassName="rootClassName"
        ></JobPost>
        <JobPost
          imageSrc="https://i.stack.imgur.com/mwFzF.png"
          profileSrc="https://i.stack.imgur.com/mwFzF.png"
          rootClassName="rootClassName2"
        ></JobPost>
        <JobPost
          imageSrc="https://i.stack.imgur.com/mwFzF.png"
          profileSrc="https://i.stack.imgur.com/mwFzF.png"
          rootClassName="rootClassName1"
        ></JobPost>
      </div>
    </div>
  )
}

export default JobsListing
