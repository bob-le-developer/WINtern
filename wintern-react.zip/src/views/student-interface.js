import React from 'react'
import { Link } from 'react-router-dom'

import { Helmet } from 'react-helmet'

import './student-interface.css'

const StudentInterface = (props) => {
  return (
    <div className="student-interface-container">
      <Helmet>
        <title>Student-Interface - Wintern</title>
        <meta property="og:title" content="Student-Interface - Wintern" />
      </Helmet>
      <div className="student-interface-sidebar">
        <nav className="student-interface-nav">
          <svg viewBox="0 0 1024 1024" className="student-interface-icon">
            <path d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
          </svg>
          <Link to="/jobs-listing" className="student-interface-navlink">
            Opportunities
          </Link>
        </nav>
        <div className="student-interface-profile">
          <img
            alt="image"
            src="https://play.teleporthq.io/static/svg/default-img.svg"
            className="student-interface-image"
          />
          <div className="student-interface-container1">
            <span className="student-interface-text">Bob</span>
            <span className="student-interface-text01">Edit Profile</span>
          </div>
        </div>
      </div>
      <h1 className="student-interface-text02">Home</h1>
      <div className="student-interface-container2">
        <span className="student-interface-text03">
          <span>Here you can view your current</span>
          <br></br>
          <span>commitments and plan your time accordingly.</span>
          <br></br>
        </span>
        <div
          data-thq="slider"
          data-navigation="true"
          data-pagination="true"
          className="student-interface-slider swiper"
        >
          <div
            data-thq="slider-wrapper"
            className="student-interface-slider-wrapper swiper-wrapper"
          >
            <div
              data-thq="slider-slide"
              className="student-interface-slider-slide swiper-slide"
            >
              <span className="student-interface-text08">Job - Current</span>
              <span className="student-interface-text09">JOB HERE</span>
            </div>
            <div
              data-thq="slider-slide"
              className="student-interface-slider-slide1 swiper-slide"
            >
              <span className="student-interface-text10">Job - Current</span>
              <span className="student-interface-text11">JOB HERE</span>
            </div>
            <div
              data-thq="slider-slide"
              className="student-interface-slider-slide2 swiper-slide"
            >
              <span className="student-interface-text12">Job - Current</span>
              <span className="student-interface-text13">JOB HERE</span>
            </div>
          </div>
          <div
            data-thq="slider-pagination"
            className="student-interface-slider-pagination swiper-pagination swiper-pagination-bullets swiper-pagination-horizontal"
          >
            <div
              data-thq="slider-pagination-bullet"
              className="swiper-pagination-bullet swiper-pagination-bullet-active"
            ></div>
          </div>
          <div
            data-thq="slider-button-prev"
            className="student-interface-slider-button-prev swiper-button-prev"
          ></div>
          <div
            data-thq="slider-button-next"
            className="student-interface-slider-button-next swiper-button-next"
          ></div>
        </div>
        <h1 className="student-interface-text14">Current Jobs</h1>
      </div>
    </div>
  )
}

export default StudentInterface
