import React from 'react'

import { Helmet } from 'react-helmet'

import './sign-up2.css'

const SignUp2 = (props) => {
  return (
    <div className="sign-up2-container">
      <Helmet>
        <title>Sign-Up2 - Wintern</title>
        <meta property="og:title" content="Sign-Up2 - Wintern" />
      </Helmet>
      <div className="sign-up2-container1">
        <div className="sign-up2-container2">
          <span className="sign-up2-text">
            <span>Username:</span>
            <br></br>
          </span>
          <div className="sign-up2-container3">
            <input
              type="email"
              id="Username"
              required="true"
              placeholder="Username or Email"
              className="sign-up2-textinput input"
            />
          </div>
        </div>
        <div className="sign-up2-container4">
          <span className="sign-up2-text03">
            <span>Age:</span>
            <br></br>
          </span>
          <div className="sign-up2-container5">
            <input
              type="number"
              id="Age"
              required="true"
              placeholder="Age"
              className="sign-up2-textinput1 input"
            />
          </div>
        </div>
        <div className="sign-up2-container6">
          <span className="sign-up2-text06">
            <span>Password:</span>
            <br></br>
          </span>
          <input
            type="password"
            id="Password"
            required="true"
            placeholder="Password"
            className="sign-up2-textinput2 input"
          />
        </div>
      </div>
      <button type="button" className="sign-up2-button button">
        <span className="sign-up2-text09">
          <span>Register Account</span>
          <br></br>
        </span>
      </button>
    </div>
  )
}

export default SignUp2
