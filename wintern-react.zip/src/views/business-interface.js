import React from 'react'
import { Link } from 'react-router-dom'

import { Helmet } from 'react-helmet'

import './business-interface.css'

const BusinessInterface = (props) => {
  return (
    <div className="business-interface-container">
      <Helmet>
        <title>Business-Interface - Wintern</title>
        <meta property="og:title" content="Business-Interface - Wintern" />
      </Helmet>
      <div className="business-interface-hero">
        <div className="business-interface-container1">
          <h1 className="business-interface-text">Welcome to Your Homepage</h1>
          <h2 className="business-interface-text01">
            Manage your interns here or post new opportunities
          </h2>
          <div className="business-interface-btn-group">
            <Link to="/classlist" className="business-interface-navlink button">
              View Interns
            </Link>
            <Link
              to="/business-post"
              className="business-interface-navlink1 button"
            >
              Post Offer
            </Link>
          </div>
          <span className="business-interface-text02">
            <span>
              <span>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non
                volutpat turpis.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <span>
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </span>
            <span>
              <span>
                Mauris luctus rutrum mi ut rhoncus. Integer in dignissim tortor.
                Lorem
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <span>
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </span>
            <span>
              <span>
                ipsum dolor sit amet, consectetur adipiscing elit.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <span>
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </span>
            <br></br>
            <span></span>
            <br></br>
            <span>
              <span>
                Mauris luctus rutrum mi ut rhoncus. Integer in dignissim tortor.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <span>
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </span>
          </span>
        </div>
      </div>
    </div>
  )
}

export default BusinessInterface
