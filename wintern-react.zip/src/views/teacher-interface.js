import React from 'react'
import { Link } from 'react-router-dom'

import { Helmet } from 'react-helmet'

import StudentDirect from '../components/student-direct'
import BusinessDirect from '../components/business-direct'
import './teacher-interface.css'

const TeacherInterface = (props) => {
  return (
    <div className="teacher-interface-container">
      <Helmet>
        <title>Teacher-Interface - Wintern</title>
        <meta property="og:title" content="Teacher-Interface - Wintern" />
      </Helmet>
      <div className="teacher-interface-features">
        <h1 className="teacher-interface-text">Welcome, Bob</h1>
        <div className="teacher-interface-separator"></div>
        <div className="teacher-interface-container1">
          <div className="teacher-interface-container2">
            <Link to="/classlist" className="teacher-interface-navlink">
              <StudentDirect
                rootClassName="rootClassName1"
                className="teacher-interface-component"
              ></StudentDirect>
            </Link>
            <div className="teacher-interface-container3"></div>
            <Link to="/jobs-listing" className="teacher-interface-navlink1">
              <BusinessDirect
                rootClassName="business-direct-root-class-name"
                className="teacher-interface-component1"
              ></BusinessDirect>
            </Link>
          </div>
          <img
            alt="image"
            src="https://images.unsplash.com/photo-1471086569966-db3eebc25a59?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDIzfHxtaW5pbWFsaXNtfGVufDB8fHx8MTYyNjQ0NTY1Nw&amp;ixlib=rb-1.2.1&amp;w=500"
            className="teacher-interface-image"
          />
        </div>
      </div>
      <div
        data-thq="slider"
        data-navigation="true"
        data-pagination="true"
        className="teacher-interface-slider swiper"
      >
        <div data-thq="slider-wrapper" className="swiper-wrapper">
          <div
            data-thq="slider-slide"
            className="teacher-interface-slider-slide swiper-slide"
          >
            <span>Tasks/Notifs Here</span>
          </div>
          <div
            data-thq="slider-slide"
            className="teacher-interface-slider-slide1 swiper-slide"
          ></div>
          <div
            data-thq="slider-slide"
            className="teacher-interface-slider-slide2 swiper-slide"
          ></div>
        </div>
        <div
          data-thq="slider-pagination"
          className="teacher-interface-slider-pagination swiper-pagination swiper-pagination-bullets swiper-pagination-horizontal"
        >
          <div
            data-thq="slider-pagination-bullet"
            className="swiper-pagination-bullet swiper-pagination-bullet-active"
          ></div>
          <div
            data-thq="slider-pagination-bullet"
            className="swiper-pagination-bullet"
          ></div>
          <div
            data-thq="slider-pagination-bullet"
            className="swiper-pagination-bullet"
          ></div>
        </div>
        <div
          data-thq="slider-button-prev"
          className="teacher-interface-slider-button-prev swiper-button-prev"
        ></div>
        <div
          data-thq="slider-button-next"
          className="teacher-interface-slider-button-next swiper-button-next"
        ></div>
      </div>
    </div>
  )
}

export default TeacherInterface
