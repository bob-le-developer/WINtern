import React from 'react'

import PropTypes from 'prop-types'

import './job-post.css'

const JobPost = (props) => {
  return (
    <div className={`job-post-blog-post-card ${props.rootClassName} `}>
      <img
        alt={props.imageAlt}
        src={props.imageSrc}
        image_src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fHBvcnRyYWl0fGVufDB8fHx8MTYyNjM3ODk3Mg&amp;ixlib=rb-1.2.1&amp;h=1000"
        className="job-post-image"
      />
      <div className="job-post-container">
        <div className="job-post-container1">
          <span className="job-post-text">{props.label}</span>
          <span className="job-post-text1">{props.when}</span>
        </div>
        <h1 className="job-post-text2">{props.title}</h1>
        <span className="job-post-text3">{props.description}</span>
        <div className="job-post-container2">
          <div className="job-post-profile">
            <img
              alt={props.profileAlt}
              src={props.profileSrc}
              className="job-post-image1"
            />
            <span className="job-post-text4">{props.author}</span>
          </div>
          <span className="job-post-text5">Read More -&gt;</span>
        </div>
      </div>
    </div>
  )
}

JobPost.defaultProps = {
  profileAlt: 'bob',
  title: 'Lorem ipsum dolor sit amet',
  description:
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non volutpat turpis. Mauris luctus rutrum mi ut rhoncus. Integer in dignissim tortor. Lorem ipsum dolor sit amet, consectetur adipiscing ...',
  label: 'ENTERPRISE',
  profileSrc:
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fHBvcnRyYWl0fGVufDB8fHx8MTYyNjM3ODk3Mg&ixlib=rb-1.2.1&h=1200',
  rootClassName: '',
  imageAlt: 'image',
  when: '3 days ago',
  imageSrc:
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fHBvcnRyYWl0fGVufDB8fHx8MTYyNjM3ODk3Mg&ixlib=rb-1.2.1&w=1000',
  author: 'bob',
}

JobPost.propTypes = {
  profileAlt: PropTypes.string,
  title: PropTypes.string,
  description: PropTypes.string,
  label: PropTypes.string,
  profileSrc: PropTypes.string,
  rootClassName: PropTypes.string,
  imageAlt: PropTypes.string,
  when: PropTypes.string,
  imageSrc: PropTypes.string,
  author: PropTypes.string,
}

export default JobPost
