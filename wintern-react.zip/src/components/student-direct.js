import React from 'react'

import PropTypes from 'prop-types'

import './student-direct.css'

const StudentDirect = (props) => {
  return (
    <div className={`student-direct-feature-card ${props.rootClassName} `}>
      <svg viewBox="0 0 1024 1024" className="student-direct-icon">
        <path
          d="M512 598q108 0 225 47t117 123v86h-684v-86q0-76 117-123t225-47zM512 512q-70 0-120-50t-50-120 50-121 120-51 120 51 50 121-50 120-120 50z"
          className=""
        ></path>
      </svg>
      <h2 className="student-direct-text">{props.businesses}</h2>
      <button type="button" className="button student-direct-button">
        {props.button}
      </button>
    </div>
  )
}

StudentDirect.defaultProps = {
  businesses: 'Students',
  description: 'View Full Class List ->',
  rootClassName: '',
  button: 'View Full Classlist ->',
}

StudentDirect.propTypes = {
  businesses: PropTypes.string,
  description: PropTypes.string,
  rootClassName: PropTypes.string,
  button: PropTypes.string,
}

export default StudentDirect
