import React from 'react'
import ReactDOM from 'react-dom'
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from 'react-router-dom'

import './style.css'
import Classlist from './views/classlist'
import StudentInterface from './views/student-interface'
import BusinessPost from './views/business-post'
import JobsListing from './views/jobs-listing'
import BusinessInterface from './views/business-interface'
import SignUp2 from './views/sign-up2'
import Home from './views/home'
import SignUp from './views/sign-up'
import TeacherInterface from './views/teacher-interface'
import NotFound from './views/not-found'

const App = () => {
  return (
    <Router>
      <Switch>
        <Route component={Classlist} exact path="/classlist" />
        <Route component={StudentInterface} exact path="/student-interface" />
        <Route component={BusinessPost} exact path="/business-post" />
        <Route component={JobsListing} exact path="/jobs-listing" />
        <Route component={BusinessInterface} exact path="/business-interface" />
        <Route component={SignUp2} exact path="/sign-up2" />
        <Route component={Home} exact path="/" />
        <Route component={SignUp} exact path="/sign-up" />
        <Route component={TeacherInterface} exact path="/teacher-interface" />
        <Route component={NotFound} path="**" />
        <Redirect to="**" />
      </Switch>
    </Router>
  )
}

ReactDOM.render(<App />, document.getElementById('app'))
